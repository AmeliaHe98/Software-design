package ca.ubc.cs.cpsc210.resourcefinder.parser;

import ca.ubc.cs.cpsc210.resourcefinder.model.*;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

// Handler for XML resource parsing
public class ResourceHandler extends DefaultHandler {
    private ResourceRegistry registry;
    private StringBuilder accumulator;
    private String name;
    private ContactInfo contactInfo;
    private ArrayList<Service> services;
    private String address;
    private GeoPoint geoPoint;
    private double lat;
    private double lon;
    private URL webaddress;
    private String phoneNum;

    // EFFECTS: constructs resource handler for XML parser
    public ResourceHandler(ResourceRegistry registry) {
        this.registry = registry;
        accumulator = new StringBuilder();
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        super.startElement(uri, localName, qName, attributes);
        if(qName.toLowerCase().equals("resource")){
            this.name = "";
            this. contactInfo = null;
            this.services = new ArrayList<>();
            this.address = "";
            this.geoPoint = null;
            this.lat = 0;
            this.lon = 0;
            this.webaddress = null;
            this.phoneNum = "";
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        String data = accumulator.toString().trim();
        accumulator.setLength(0);

        if(qName.toLowerCase().equals("name"))
            this.name = data;
        if(qName.toLowerCase().equals("address"))
            this.address = data;
        if(qName.toLowerCase().equals("webaddress"))
            try {
                this.webaddress = new URL(data);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        if(qName.toLowerCase().equals("phone"))
            this.phoneNum = data;
        if(qName.toLowerCase().equals("lat"))
            this.lat = Double.parseDouble(data);
        if(qName.toLowerCase().equals("lon"))
            this.lon = Double.parseDouble(data);
        if(qName.toLowerCase().equals("location"))
            this.geoPoint = new GeoPoint(this.lat, this.lon);
        if(qName.toLowerCase().equals("service")){
            if (data.equals("Shelter"))
                services.add(Service.SHELTER);
            else if (data.equals("Food"))
                services.add(Service.FOOD);
            else if (data.equals("Counselling"))
                services.add(Service.COUNSELLING);
            else if (data.equals("Youth services"))
                services.add(Service.YOUTH);
            else if (data.equals("Senior services"))
                services.add(Service.SENIOR);
            else if (data.equals("Legal advice"))
                services.add(Service.LEGAL);
        }
        if(qName.toLowerCase().equals("resource")) {
            if (this.name != "" && this.address != "" && this.phoneNum != "" && this.webaddress != null
                    && this.geoPoint != null && !this.services.isEmpty()) {
                contactInfo = new ContactInfo(address, geoPoint, webaddress, phoneNum);
                Resource resource = new Resource(name, contactInfo);

                for (Service service : services) {
                    resource.addService(service);
                }
                registry.addResource(resource);
            }
        }
        if(qName.toLowerCase().equals("resources")){
            if (registry.getResources().size() == 0) {
                throw new SAXException();
            }
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        super.characters(ch, start, length);
        accumulator.append(ch, start, length);
    }
}
