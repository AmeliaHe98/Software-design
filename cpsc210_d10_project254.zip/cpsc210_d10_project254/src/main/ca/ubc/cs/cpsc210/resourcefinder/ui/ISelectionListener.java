package ca.ubc.cs.cpsc210.resourcefinder.ui;

// Service selection listener
public interface ISelectionListener {
    // called when service selection has been changed
    void update();
}
