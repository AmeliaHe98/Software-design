package ca.ubc.cs.cpsc210.resourcefinder.tests;

// Unit tests for XMLResourceParser class
public class ResourceParserBadURLTest {
    // TODO: test the parser when a resource has a bad URL (e.g., data/resourceWithBadURL.xml)
}