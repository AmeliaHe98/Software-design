package ca.ubc.cs.cpsc210.machine.test;


import ca.ubc.cs.cpsc210.machine.model.Coin;
import ca.ubc.cs.cpsc210.machine.model.PaymentUnit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Queue;

import static ca.ubc.cs.cpsc210.machine.model.Coin.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

public class PaymentUnitTest {
    private PaymentUnit testPayment;

    @BeforeEach
    public void runBefore() {
        testPayment = new PaymentUnit();
    }

    @Test
    public void testPaymentUnit() {
        assertEquals(0,testPayment.getValueOfCoinsBanked());
    }

    @Test
    public void testClearCoinsBanked() {
        assertEquals(0,testPayment.getValueOfCoinsBanked());
    }

    @Test
    public void testAddCoinsToBanked0() {
        testPayment.addCoinsToBanked(DIME, 10);
        assertEquals(Coin.DIME.getValue()*10,testPayment.getValueOfCoinsBanked());
    }

    @Test
    public void testAddCoinsToBanked1() {
        testPayment.addCoinsToBanked(NICKEL, 10);
        assertEquals(Coin.NICKEL.getValue()*10,testPayment.getValueOfCoinsBanked());
    }

    @Test
    public void testAddCoinsToBanked2() {
        testPayment.addCoinsToBanked(QUARTER, 10);
        assertEquals(Coin.QUARTER.getValue()*10,testPayment.getValueOfCoinsBanked());
    }

    @Test
    public void testAddCoinsToBanked3() {
        testPayment.addCoinsToBanked(LOONIE, 10);
        assertEquals(Coin.LOONIE.getValue()*10,testPayment.getValueOfCoinsBanked());
    }

    @Test
    public void testGetNumberOfCoinsBankedOfType() {
        testPayment.addCoinsToBanked(LOONIE, 10);
        assertEquals(10,testPayment.getNumberOfCoinsBankedOfType(LOONIE));
        testPayment.addCoinsToBanked(QUARTER, 9);
        assertEquals(9,testPayment.getNumberOfCoinsBankedOfType(QUARTER));
        testPayment.addCoinsToBanked(DIME, 8);
        assertEquals(8,testPayment.getNumberOfCoinsBankedOfType(DIME));
        testPayment.addCoinsToBanked(NICKEL, 7);
        assertEquals(7,testPayment.getNumberOfCoinsBankedOfType(NICKEL));
    }

    @Test
    public void testGetValueOfCoinsBanked() {
        testPayment.addCoinsToBanked(LOONIE, 10);
        assertEquals(Coin.LOONIE.getValue()*10,testPayment.getValueOfCoinsBanked());
        testPayment.addCoinsToBanked(QUARTER, 9);
        assertEquals(Coin.LOONIE.getValue()*10+Coin.QUARTER.getValue()*9,testPayment.getValueOfCoinsBanked());
        testPayment.addCoinsToBanked(DIME, 8);
        assertEquals(Coin.LOONIE.getValue()*10+Coin.QUARTER.getValue()*9+Coin.DIME.getValue()*8,testPayment.getValueOfCoinsBanked());
        testPayment.addCoinsToBanked(NICKEL, 7);
        assertEquals(Coin.LOONIE.getValue()*10+Coin.QUARTER.getValue()*9+Coin.DIME.getValue()*8+Coin.NICKEL.getValue()*7,testPayment.getValueOfCoinsBanked());

    }

    @Test
    public void testInsertCoins() {
        testPayment.insertCoin(LOONIE);
        assertEquals(Coin.LOONIE.getValue(),testPayment.getValueOfCoinsInserted());
    }

    @Test
    public void testClearCoins() {
        testPayment.addCoinsToBanked(DIME, 10);
        testPayment.addCoinsToBanked(QUARTER, 10);
        testPayment.addCoinsToBanked(NICKEL, 10);
        testPayment.addCoinsToBanked(LOONIE, 10);
        testPayment.clearCoinsBanked();
        assertEquals(0,testPayment.getNumberOfCoinsBankedOfType(DIME));
        assertEquals(0,testPayment.getNumberOfCoinsBankedOfType(QUARTER));
        assertEquals(0,testPayment.getNumberOfCoinsBankedOfType(NICKEL));
        assertEquals(0,testPayment.getNumberOfCoinsBankedOfType(LOONIE));
    }

    @Test
    public void testCancelTransaction0() {
        testPayment.insertCoin(LOONIE);
        testPayment.cancelTransaction();
        assertEquals(0,testPayment.getValueOfCoinsInserted());
    }

    @Test
    public void testCancelTransaction1() {
        testPayment.insertCoin(LOONIE);
        testPayment.insertCoin(QUARTER);
        testPayment.cancelTransaction();
        assertEquals(0,testPayment.getValueOfCoinsInserted());
    }

    @Test
    public void testMakePurchase0() {
        testPayment.insertCoin( LOONIE);
        testPayment.makePurchase(100);
        assertEquals(0, testPayment.getValueOfCoinsInserted());
        assertEquals(1,testPayment.getNumberOfCoinsBankedOfType(LOONIE));
    }

    @Test
    public void testMakePurchase1() {
        testPayment.addCoinsToBanked(QUARTER,4);
        testPayment.insertCoin( LOONIE);
        testPayment.makePurchase(25);
        assertEquals(0, testPayment.getValueOfCoinsInserted());
        assertEquals(1,testPayment.getNumberOfCoinsBankedOfType(QUARTER));
        assertEquals(1,testPayment.getNumberOfCoinsBankedOfType(LOONIE));
    }

    @Test
    public void testMakePurchase2() {
        testPayment.addCoinsToBanked(DIME,10);
        testPayment.insertCoin( LOONIE);
        testPayment.makePurchase(20);
        assertEquals(0, testPayment.getValueOfCoinsInserted());
        assertEquals(2,testPayment.getNumberOfCoinsBankedOfType(DIME));
        assertEquals(1,testPayment.getNumberOfCoinsBankedOfType(LOONIE));
    }

    @Test
    public void testMakePurchase3() {
        testPayment.addCoinsToBanked(QUARTER,2);
        testPayment.addCoinsToBanked(DIME,2);
        testPayment.addCoinsToBanked(NICKEL,6);
        testPayment.insertCoin( LOONIE);
        testPayment.makePurchase(70);
        assertEquals(0, testPayment.getValueOfCoinsInserted());
        assertEquals(1,testPayment.getNumberOfCoinsBankedOfType(QUARTER));
        assertEquals(2,testPayment.getNumberOfCoinsBankedOfType(DIME));
        assertEquals(5,testPayment.getNumberOfCoinsBankedOfType(NICKEL));
    }

    @Test
    public void testMakePurchase4() {
        testPayment.addCoinsToBanked(LOONIE,2);
        testPayment.insertCoin( LOONIE);
        testPayment.insertCoin( LOONIE);
        testPayment.insertCoin( LOONIE);
        testPayment.makePurchase(90);
        assertEquals(0, testPayment.getValueOfCoinsInserted());
        assertEquals(3,testPayment.getNumberOfCoinsBankedOfType(LOONIE));
    }


}
