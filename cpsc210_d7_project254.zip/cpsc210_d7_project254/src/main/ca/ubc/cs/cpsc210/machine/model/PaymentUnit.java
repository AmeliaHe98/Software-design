package ca.ubc.cs.cpsc210.machine.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * Represents the payment unit in a vending machine.
 */
public class PaymentUnit {
    private int numLoonies;   // number of loonies banked in machine for making change
    private int numQuarters;  // number of quarters banked in machine for making change
    private int numDimes;     // number of dimes banked in machine for making change
    private int numNickels;   // number of nickels banked in machine for making change
    private List<Coin> currentTransaction;   // list of coins inserted into machine during current transaction

    // EFFECTS: constructs a payment unit with no banked coins and no coins inserted into the machine
    // as part of a payment
    public PaymentUnit() {
        numLoonies = 0;
        numQuarters = 0;
        numDimes = 0;
        numNickels = 0;
        currentTransaction = new ArrayList<>();
    }

    // MODIFIES: this
    // EFFECTS: clears all the coins banked in the unit
    public void clearCoinsBanked() {
        numLoonies = 0;
        numQuarters = 0;
        numDimes = 0;
        numNickels = 0;
    }

    // REQUIRES: number > 0
    // MODIFIES: this
    // EFFECTS: adds number coins of type c to the banked coins in the unit
    public void addCoinsToBanked(Coin c, int number) {
        int i = 0;
        if (c == Coin.DIME) {
            while (i < number) {
                numDimes++;
                i++;
            }
        }
        else if (c == Coin.LOONIE) {
            while (i < number){
                numLoonies++;
                i++;
            }
        }
        else if (c == Coin.NICKEL) {
            while (i < number) {
                numNickels++;
                i++;
            }
        } else {
            while (i < number){
                numQuarters++;
                i++;
            }
        }
    }

    // EFFECTS: returns number of coins banked of the given type
    public int getNumberOfCoinsBankedOfType(Coin c) {
        if (c == Coin.DIME)
            return numDimes;
        else if (c == Coin.LOONIE)
            return numLoonies;
        else if (c == Coin.NICKEL)
            return numNickels;
        else
            return numQuarters;
    }

    // EFFECTS: returns the total value of all coins banked in the unit
    public int getValueOfCoinsBanked() {
        int value;
        value = numDimes * 10 + numQuarters * 25 + numNickels * 5 + numLoonies * 100;
        return value;
    }

    // MODIFIES: this
    // EFFECTS: adds coin c to the unit as a part of a transaction
    public void insertCoin(Coin c) {
        currentTransaction.add(c);
    }

    // EFFECTS: returns value of coins inserted for current transaction
    public int getValueOfCoinsInserted() {
        int value = 0;
        for (Coin next : currentTransaction) {
            value += next.getValue();
        }
        return value;
    }

    // MODIFIES: this
    // EFFECTS: coins inserted for current transaction are cleared; list of coins
    // inserted for current transaction is returned in the order in which they were inserted.
    public List<Coin> cancelTransaction() {
        List<Coin> returnTransaction = new ArrayList<>(currentTransaction);
        currentTransaction.clear();
        return returnTransaction;

    }

    // REQUIRES: cost <= total value of coins inserted as part of current transaction
    // MODIFIES: this
    // EFFECTS: adds coins inserted to coins banked in unit and returns list of coins that will be provided as change.
    // Coins of largest possible value are used when determining the change.  Change in full is not guaranteed -
    // will provide only as many coins as are banked in the machine, without going over the amount due.
    public List<Coin> makePurchase(int cost) {
        for(Coin next: currentTransaction) {
            addCoinsToBanked(next, 1);
        }
        List<Coin> newTransaction = new ArrayList<>();
        int diff = getValueOfCoinsInserted() - cost;
        while (diff>=Coin.LOONIE.getValue()&&numLoonies>0) {
            diff -= 100;
            newTransaction.add(Coin.LOONIE);
            numLoonies--;

        }
         while (diff>=Coin.QUARTER.getValue()&&numQuarters>0){
             diff -= 25;
             newTransaction.add(Coin.QUARTER);
             numQuarters--;
         }
        while (diff>=Coin.DIME.getValue()&&numDimes>0){
            diff -= 10;
            newTransaction.add(Coin.DIME);
            numDimes--;
        }
        while (diff>=Coin.NICKEL.getValue()&&numNickels>0){
            diff -= 5;
            newTransaction.add(Coin.NICKEL);
            numNickels--;
        }

        currentTransaction.clear();
        return newTransaction;
    }
}

