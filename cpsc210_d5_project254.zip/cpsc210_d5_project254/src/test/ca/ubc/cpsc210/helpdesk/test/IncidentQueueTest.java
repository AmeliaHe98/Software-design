package ca.ubc.cpsc210.helpdesk.test;
import ca.ubc.cpsc210.helpdesk.model.Incident;
import ca.ubc.cpsc210.helpdesk.model.IncidentQueue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static ca.ubc.cpsc210.helpdesk.model.IncidentQueue.MAX_SIZE;
import static org.junit.jupiter.api.Assertions.*;

public class IncidentQueueTest {
    // Design your unit tests for the IncidentQueue class here
    private IncidentQueue IncidentQueueTest;
    private Incident i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11;

    @BeforeEach
    public void runBefore(){
        IncidentQueueTest = new IncidentQueue();
        i1 = new Incident(1, "Case 1");
        i2 = new Incident(2, "Case 2");
        i3 = new Incident(3, "Case 3");
        i4 = new Incident(4, "Case 4");
        i5 = new Incident(5, "Case 5");
        i6 = new Incident(6, "Case 6");
        i7 = new Incident(7, "Case 7");
        i8 = new Incident(8, "Case 8");
        i9 = new Incident(9, "Case 9");
        i10 = new Incident(10, "Case 10");
        i11 = new Incident(11, "Case 11");

    }

    @Test
    public void testConstructor(){
        assertTrue(IncidentQueueTest.isEmpty());
    }

    @Test
    public void testAddIncident0(){
        assertEquals(0, IncidentQueueTest.length());
        assertEquals(true, IncidentQueueTest.addIncident(i1));
        assertEquals(1, IncidentQueueTest.length());
    }

    @Test
    public void testAddIncident1(){
        IncidentQueueTest.addIncident(i1);
        IncidentQueueTest.addIncident(i2);
        IncidentQueueTest.addIncident(i3);
        IncidentQueueTest.addIncident(i4);
        assertEquals(4, IncidentQueueTest.length());
        IncidentQueueTest.addIncident(i5);
        IncidentQueueTest.addIncident(i6);
        IncidentQueueTest.addIncident(i7);
        IncidentQueueTest.addIncident(i8);
        IncidentQueueTest.addIncident(i9);
        IncidentQueueTest.addIncident(i10);
        assertEquals(10, IncidentQueueTest.length());
    }

    @Test
    public void testAddIncident2(){
        IncidentQueueTest.addIncident(i1);
        IncidentQueueTest.addIncident(i2);
        IncidentQueueTest.addIncident(i3);
        IncidentQueueTest.addIncident(i4);
        IncidentQueueTest.addIncident(i5);
        IncidentQueueTest.addIncident(i6);
        IncidentQueueTest.addIncident(i7);
        IncidentQueueTest.addIncident(i8);
        IncidentQueueTest.addIncident(i9);
        IncidentQueueTest.addIncident(i10);
        assertEquals(false, IncidentQueueTest.addIncident(i11));
    }

    @Test
    public void TestGetNextIncident0(){
        IncidentQueueTest.addIncident(i1);
        IncidentQueueTest.getNextIncident();
        assertEquals(0, IncidentQueueTest.length());
    }

    @Test
    public void TestGetNextIncident1(){
        IncidentQueueTest.addIncident(i1);
        IncidentQueueTest.addIncident(i2);
        IncidentQueueTest.addIncident(i3);
        IncidentQueueTest.getNextIncident();
        assertEquals(2, IncidentQueueTest.length());
        IncidentQueueTest.getNextIncident();
        assertEquals(1, IncidentQueueTest.length());
    }

    @Test
    public void TestGetPositionInQueueOfCaseNumber(){
        IncidentQueueTest.addIncident(i6);
        IncidentQueueTest.addIncident(i1);
        IncidentQueueTest.addIncident(i3);
        IncidentQueueTest.addIncident(i4);
        IncidentQueueTest.addIncident(i2);
        IncidentQueueTest.addIncident(i5);
        assertEquals(2, IncidentQueueTest.getPositionInQueueOfCaseNumber(1));
        assertEquals(6, IncidentQueueTest.getPositionInQueueOfCaseNumber(5));
        assertEquals(-1, IncidentQueueTest.getPositionInQueueOfCaseNumber(7));
    }

    @Test
    public void TestLength0(){
        assertEquals(0, IncidentQueueTest.length());
    }

    @Test
    public void TestLength1(){
        IncidentQueueTest.addIncident(i1);
        IncidentQueueTest.addIncident(i2);
        IncidentQueueTest.addIncident(i3);
        IncidentQueueTest.addIncident(i4);
        IncidentQueueTest.addIncident(i5);
        IncidentQueueTest.addIncident(i6);
        IncidentQueueTest.addIncident(i7);
        IncidentQueueTest.addIncident(i8);
        IncidentQueueTest.addIncident(i9);
        IncidentQueueTest.addIncident(i10);
        assertEquals(10, IncidentQueueTest.length());
    }

    @Test
    public void TestIsEmpty(){
        assertTrue(IncidentQueueTest.isEmpty());
        IncidentQueueTest.addIncident(i1);
        assertFalse(IncidentQueueTest.isEmpty());
    }

    @Test
    public void TestIsFull(){
        assertFalse(IncidentQueueTest.isFull());
        IncidentQueueTest.addIncident(i1);
        IncidentQueueTest.addIncident(i2);
        IncidentQueueTest.addIncident(i3);
        IncidentQueueTest.addIncident(i4);
        IncidentQueueTest.addIncident(i5);
        IncidentQueueTest.addIncident(i6);
        assertFalse(IncidentQueueTest.isFull());
        IncidentQueueTest.addIncident(i7);
        IncidentQueueTest.addIncident(i8);
        IncidentQueueTest.addIncident(i9);
        IncidentQueueTest.addIncident(i10);
        assertTrue(IncidentQueueTest.isFull());
    }


}