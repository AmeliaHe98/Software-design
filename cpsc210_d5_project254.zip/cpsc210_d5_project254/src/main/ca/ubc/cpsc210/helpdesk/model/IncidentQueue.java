package ca.ubc.cpsc210.helpdesk.model;

import java.util.ArrayList;
import java.util.List;

// Represents a queue of incidents to be handled by helpdesk
// with maximum size MAX_SIZE
public class IncidentQueue {
    public static final int MAX_SIZE = 10;
    private List<Incident> queue;
    // TODO: complete the design of the IncidentQueue class

    // EFFECTS: constructs new IncidentQueue as an empty queue
    public IncidentQueue (){
        queue = new ArrayList<>();
    }

    // MODIFIES: this
    // EFFECTS: add queue to end of the queue if queue is not full. If full, return false.
    public boolean addIncident (Incident i){
        if(!(isFull())){
            queue.add(i);
            return true;
        }
        else
            return false;
    }

    // REQUIRES: queue is not empty
    // MODIFIES: this
    // EFFECTS: removes the Incident at the front of the queue and returns it
    public Incident getNextIncident (){
        return queue.remove(0);
    }

    // REQUIRES: there is only one incident with i
    // EFFECTS: returns the position (i) in the queue of the Incident with (i). If
    // there is no incident with the given (i), then return -1
    public int getPositionInQueueOfCaseNumber (int i){
        for (int j = 0; j < queue.size(); j++)
        {
            Incident e = queue.get(j);
            if (e.getCaseNum()==i){
                return ++j;
            }
        }
        return -1;
    }

    // EFFECTS: represents the number of incidents currently in the queue
    public int length (){
        return queue.size();
    }

    // EFFECTS: returns true if the queue is empty, false otherwise
    public boolean isEmpty (){
        return queue.isEmpty();
    }

    // EFFECTS: returns true if the queue is full, false otherwise
    public boolean isFull (){
        if (queue.size()==MAX_SIZE)
            return true;
        else
            return false;
    }
}
