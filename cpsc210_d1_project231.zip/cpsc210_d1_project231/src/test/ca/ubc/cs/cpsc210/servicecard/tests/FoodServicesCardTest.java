package ca.ubc.cs.cpsc210.servicecard.tests;

import ca.ubc.cs.cpsc210.servicecard.model.FoodServicesCard;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static ca.ubc.cs.cpsc210.servicecard.model.FoodServicesCard.CASH_BACK_REWARD;
import static ca.ubc.cs.cpsc210.servicecard.model.FoodServicesCard.POINTS_NEEDED_FOR_CASH_BACK;
import static ca.ubc.cs.cpsc210.servicecard.model.FoodServicesCard.REWARD_POINTS_PER_CENT_CHARGED;
import static org.junit.jupiter.api.Assertions.*;

// Unit tests for FoodServiceCard class
public class FoodServicesCardTest {
    public static final int INITIAL_BALANCE = 10000;
    private FoodServicesCard testCard;

    @BeforeEach
    public void setUp() throws Exception {
        testCard = new FoodServicesCard(INITIAL_BALANCE);
    }

    @Test
    public void testConstructor() {
        assertEquals(INITIAL_BALANCE, testCard.getBalance());
        assertEquals(0, testCard.getRewardPoints());
    }

    @Test
    public void testReload() {
        assertEquals(10000, testCard.getBalance());
        testCard.reload(5);
        assertEquals(10005, testCard.getBalance());
        testCard.reload(10);
        assertEquals(10015, testCard.getBalance());
    }

    @Test
    public void testMakePurchase0() {
        assertEquals(false, testCard.makePurchase(20000));
    }

    @Test
    public void testMakePurchase1() {
        assertEquals(true, testCard.makePurchase(50));
        assertEquals(INITIAL_BALANCE - 50, testCard.getBalance());
        assertEquals(50 * REWARD_POINTS_PER_CENT_CHARGED, testCard.getRewardPoints());
    }

    @Test
    public void testMakePurchase2() {
        assertEquals(true, testCard.makePurchase(2000));
        assertEquals(INITIAL_BALANCE - 2000 + CASH_BACK_REWARD, testCard.getBalance());
        assertEquals(2000 - POINTS_NEEDED_FOR_CASH_BACK, testCard.getRewardPoints());

    }

    @Test
    public void testMakePurchase3() {
        testCard.makePurchase(5);
        assertEquals(INITIAL_BALANCE - 5, testCard.getBalance());
        assertEquals(5, testCard.getRewardPoints());
        testCard.makePurchase(20);
        assertEquals(INITIAL_BALANCE - 25, testCard.getBalance());
        assertEquals(25, testCard.getRewardPoints());
    }

    @Test
    public void testMakePurchase4() {
        testCard.makePurchase(4000);
        assertEquals(INITIAL_BALANCE - 4000 + 2 * CASH_BACK_REWARD, testCard.getBalance());
        assertEquals(0, testCard.getRewardPoints());
    }

    @Test
    public void testGetBalance() {
        assertEquals(10000, testCard.getBalance());
    }

    @Test
    public void testGetRewardPoints() {
        assertEquals(0, testCard.getRewardPoints());
    }
}