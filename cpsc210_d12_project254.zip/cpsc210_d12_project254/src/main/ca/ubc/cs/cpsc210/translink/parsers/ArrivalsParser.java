package ca.ubc.cs.cpsc210.translink.parsers;

import ca.ubc.cs.cpsc210.translink.model.Arrival;
import ca.ubc.cs.cpsc210.translink.model.Route;
import ca.ubc.cs.cpsc210.translink.model.RouteManager;
import ca.ubc.cs.cpsc210.translink.model.Stop;
import ca.ubc.cs.cpsc210.translink.parsers.exception.ArrivalsDataMissingException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * A parser for the data returned by the Translink arrivals at a stop query
 */
public class ArrivalsParser {
    private static String destination;
    private static int timeToStop;
    private static String status;
    private static String routeNo;
    private static JSONObject arrival;
    private static Route route;
    private static boolean exception;
    /**
     * Parse arrivals from JSON response produced by TransLink query.  All parsed arrivals are
     * added to the given stop assuming that corresponding JSON object has a RouteNo: and an
     * array of Schedules:
     * Each schedule must have an ExpectedCountdown, ScheduleStatus, and Destination.  If
     * any of the aforementioned elements is missing, the arrival is not added to the stop.
     *
     * @param stop             stop to which parsed arrivals are to be added
     * @param jsonResponse    the JSON response produced by Translink
     * @throws JSONException  when:
     * <ul>
     *     <li>JSON response does not have expected format (JSON syntax problem)</li>
     *     <li>JSON response is not an array</li>
     * </ul>
     * @throws ArrivalsDataMissingException  when no arrivals are found in the reply
     */
    public static void parseArrivals(Stop stop, String jsonResponse)
            throws JSONException, ArrivalsDataMissingException {
        try {
        exception = false;
        JSONArray arrivals = new JSONArray(jsonResponse);
        for (int index = 0; index < arrivals.length(); index++) {
            arrival = arrivals.getJSONObject(index);
            if (arrival.has("RouteNo") && arrival.has("Schedules")) {
                routeNo = arrival.getString("RouteNo");
                route = RouteManager.getInstance().getRouteWithNumber(routeNo);
                try {
                    parseSchedule(arrival.getJSONArray("Schedules"), stop);
                } catch (ArrivalsDataMissingException e) {
                    exception = true;
                }
            }
        }
        if (exception==true)
            throw new ArrivalsDataMissingException();
    } catch (JSONException e) {
        e.printStackTrace();
    }
    }

    public static void parseSchedule(JSONArray schedule, Stop stop) throws JSONException, ArrivalsDataMissingException {
        JSONObject parseSchedule;
        int exception = 0;

        for (int i = 0; i < schedule.length(); i++) {
            parseSchedule = schedule.getJSONObject(i);
            if (parseSchedule.has("ExpectedCountdown") && parseSchedule.has("ScheduleStatus") && parseSchedule.has("Destination")) {
                timeToStop = parseSchedule.getInt("ExpectedCountdown");
                status = parseSchedule.getString("ScheduleStatus");
                destination = parseSchedule.getString("Destination");

                Arrival newArrival = new Arrival(timeToStop, destination, route);
                newArrival.setStatus(status);
                stop.addArrival(newArrival);
            } else exception++;
        }
        if (exception == schedule.length()) {
            throw new ArrivalsDataMissingException();
        }
    }
}
