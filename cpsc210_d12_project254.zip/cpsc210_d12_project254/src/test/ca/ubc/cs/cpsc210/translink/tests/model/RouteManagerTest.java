package ca.ubc.cs.cpsc210.translink.tests.model;

import ca.ubc.cs.cpsc210.translink.model.Route;
import ca.ubc.cs.cpsc210.translink.model.RouteManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;


/**
 * Test the RouteManager
 */
public class RouteManagerTest {

    @BeforeEach
    public void setup() {
        RouteManager.getInstance().clearRoutes();
    }

    @Test
    public void testBasic() {
        Route r43 = new Route("43");
        Route r = RouteManager.getInstance().getRouteWithNumber("43");
        assertEquals(r43, r);
    }

    @Test
    public void testConstructor() {
        assertEquals(0, RouteManager.getInstance().getNumRoutes());
    }

    @Test
    public void testGetRouteWithNumber() {
        RouteManager.getInstance().getRouteWithNumber("43");
        assertEquals(1, RouteManager.getInstance().getNumRoutes());
        RouteManager.getInstance().getRouteWithNumber("1");
        assertEquals(2, RouteManager.getInstance().getNumRoutes());
        RouteManager.getInstance().getRouteWithNumber("2");
        assertEquals(3, RouteManager.getInstance().getNumRoutes());
        RouteManager.getInstance().getRouteWithNumber("43");
        assertEquals(3, RouteManager.getInstance().getNumRoutes());
        RouteManager.getInstance().getRouteWithNumber("43", "A");
        assertEquals(3, RouteManager.getInstance().getNumRoutes());
        RouteManager.getInstance().getRouteWithNumber("53", "A");
        assertEquals(4, RouteManager.getInstance().getNumRoutes());
        RouteManager.getInstance().getRouteWithNumber("53", "B");
        assertEquals(4, RouteManager.getInstance().getNumRoutes());
    }

    @Test
    public void testClearRoutes() {
        RouteManager.getInstance().getRouteWithNumber("43");
        RouteManager.getInstance().getRouteWithNumber("1");
        assertEquals(2, RouteManager.getInstance().getNumRoutes());
        RouteManager.getInstance().clearRoutes();
        assertEquals(0, RouteManager.getInstance().getNumRoutes());
    }
}
