package ca.ubc.cs.cpsc210.translink.tests.model;

import ca.ubc.cs.cpsc210.translink.model.Stop;
import ca.ubc.cs.cpsc210.translink.model.StopManager;
import ca.ubc.cs.cpsc210.translink.model.exception.StopException;
import ca.ubc.cs.cpsc210.translink.util.LatLon;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.fail;


/**
 * Test the StopManager
 */
public class StopManagerTest {

    @BeforeEach
    public void setup() {
        StopManager.getInstance().clearStops();
    }

    @Test
    public void testBasic() {
        Stop s9999 = new Stop(9999, "My house", new LatLon(-49.2, 123.2));
        Stop r = StopManager.getInstance().getStopWithNumber(9999);
        assertEquals(s9999, r);
    }

    @Test
    public void testConstructor(){
        assertEquals(0, StopManager.getInstance().getNumStops());
        assertEquals(null, StopManager.getInstance().getSelected());
    }

    @Test
    public void testGetStopWithNumber(){
        LatLon locn1 = new LatLon(100,100);
        LatLon locn2 = new LatLon(200,200);
        StopManager.getInstance().getStopWithNumber(10);
        assertEquals(1, StopManager.getInstance().getNumStops());
        StopManager.getInstance().getStopWithNumber(20);
        assertEquals(2, StopManager.getInstance().getNumStops());
        StopManager.getInstance().getStopWithNumber(1, "1", locn1);
        assertEquals(3, StopManager.getInstance().getNumStops());
        StopManager.getInstance().getStopWithNumber(10);
        assertEquals(3, StopManager.getInstance().getNumStops());
        StopManager.getInstance().getStopWithNumber(1, "1", locn2);
        assertEquals(3, StopManager.getInstance().getNumStops());
        StopManager.getInstance().getStopWithNumber(2, "2", locn2);
        assertEquals(4, StopManager.getInstance().getNumStops());
        StopManager.getInstance().clearStops();
        assertEquals(0, StopManager.getInstance().getNumStops());
    }

    @Test
    public void testSetSelectedAllWorking() throws StopException {
        LatLon locn1 = new LatLon(100,100);
        LatLon locn2 = new LatLon(200,200);
        StopManager.getInstance().getStopWithNumber(1, "1", locn1);
        StopManager.getInstance().getStopWithNumber(2, "2", locn2);
        try {
            StopManager.getInstance().setSelected(new Stop(1,"1", locn1));
        }catch (StopException e){
            // Expected
        }
    }

    @Test
    public void testSetSelectedStopException() throws StopException {
        LatLon locn1 = new LatLon(100,100);
        LatLon locn2 = new LatLon(200,200);
        Stop s1 = new Stop(1,"1", locn1);
        Stop s2 = new Stop(2,"2", locn2);
        try {
        StopManager.getInstance().setSelected(s1);
        StopManager.getInstance().setSelected(s2);
        fail("Stop exception was thrown");
        }catch (StopException e){

        }
    }

    @Test
    public void testFindNearestTo(){
        LatLon locn1 = new LatLon(100,100);
        LatLon near = new LatLon(99,99);
        Stop s1 = new Stop(1,"1", locn1);
        StopManager.getInstance().getStopWithNumber(1, "1", locn1);
        assertEquals(null, StopManager.getInstance().findNearestTo(near));
    }
}
