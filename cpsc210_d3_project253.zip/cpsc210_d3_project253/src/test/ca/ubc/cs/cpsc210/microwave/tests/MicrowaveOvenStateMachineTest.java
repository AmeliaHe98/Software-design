package ca.ubc.cs.cpsc210.microwave.tests;

import ca.ubc.cs.cpsc210.microwave.model.MicrowaveOvenState;
import ca.ubc.cs.cpsc210.microwave.model.MicrowaveOvenStateMachine;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

// unit tests for MicrowaveOvenStateMachine
public class MicrowaveOvenStateMachineTest {
    private MicrowaveOvenStateMachine testMicrowave;
    private MicrowaveOvenState currentState;

    @BeforeEach
    public void runBefore(){
        testMicrowave = new MicrowaveOvenStateMachine();
    }

    @Test
    public void testConstructor(){
        assertEquals(MicrowaveOvenState.IDLE, testMicrowave.getCurrentState());
    }

    @Test
    public void testSetTime(){
        assertEquals(MicrowaveOvenState.IDLE, testMicrowave.getCurrentState());
        assertEquals(null, testMicrowave.pause());
        assertEquals(null, testMicrowave.resume());
        assertEquals(null, testMicrowave.cancel());
        assertEquals(null, testMicrowave.start());
        assertEquals(null, testMicrowave.setPowerLevel(10));
        assertEquals(MicrowaveOvenState.PROGRAMMED, testMicrowave.setTime(10,0));
        assertEquals(MicrowaveOvenState.PROGRAMMED, testMicrowave.getCurrentState());
        assertEquals(null, testMicrowave.pause());
        assertEquals(null, testMicrowave.resume());
        assertEquals(null, testMicrowave.setTime(10,0));
    }

    public void testSetTime0(){
        assertEquals(MicrowaveOvenState.IDLE, testMicrowave.getCurrentState());
        assertEquals(MicrowaveOvenState.PROGRAMMED, testMicrowave.setTime(10,0));
        assertEquals(MicrowaveOvenState.PROGRAMMED, testMicrowave.setPowerLevel(10));
        assertEquals(MicrowaveOvenState.IDLE, testMicrowave.cancel());
        assertEquals(null, testMicrowave.setPowerLevel(10));
        assertEquals(null, testMicrowave.start());
        assertEquals(null, testMicrowave.pause());
        assertEquals(null, testMicrowave.resume());
        assertEquals(null, testMicrowave.cancel());
    }
    @Test
    public void testSetTime1(){
        assertEquals(MicrowaveOvenState.IDLE, testMicrowave.getCurrentState());
        assertEquals(MicrowaveOvenState.PROGRAMMED, testMicrowave.setTime(10,0));
        assertEquals(MicrowaveOvenState.PROGRAMMED, testMicrowave.setPowerLevel(10));
        assertEquals(MicrowaveOvenState.PROGRAMMED, testMicrowave.setPowerLevel(20));
        assertEquals(null, testMicrowave.setTime(10,0));
        assertEquals(null, testMicrowave.resume());
        assertEquals(null, testMicrowave.pause());
    }

    @Test
    public void testSetTime2(){
        assertEquals(MicrowaveOvenState.IDLE, testMicrowave.getCurrentState());
        assertEquals(MicrowaveOvenState.PROGRAMMED, testMicrowave.setTime(10,0));
        assertEquals(MicrowaveOvenState.COOKING, testMicrowave.start());
        assertEquals(null, testMicrowave.setTime(10,0));
        assertEquals(null, testMicrowave.resume());
        assertEquals(null, testMicrowave.cancel());
        assertEquals(null, testMicrowave.start());
        assertEquals(null, testMicrowave.setPowerLevel(20));
    }

    @Test
    public void testSetTime3(){
        assertEquals(MicrowaveOvenState.IDLE, testMicrowave.getCurrentState());
        assertEquals(MicrowaveOvenState.PROGRAMMED, testMicrowave.setTime(10,0));
        assertEquals(MicrowaveOvenState.COOKING, testMicrowave.start());
        assertEquals(MicrowaveOvenState.PAUSED, testMicrowave.pause());
        assertEquals(null, testMicrowave.setTime(10,0));
        assertEquals(null, testMicrowave.pause());
        assertEquals(null, testMicrowave.start());
        assertEquals(null, testMicrowave.setPowerLevel(20));
    }

    @Test
    public void testSetTime4(){
        assertEquals(MicrowaveOvenState.IDLE, testMicrowave.getCurrentState());
        assertEquals(MicrowaveOvenState.PROGRAMMED, testMicrowave.setTime(10,0));
        assertEquals(MicrowaveOvenState.COOKING, testMicrowave.start());
        assertEquals(MicrowaveOvenState.PAUSED, testMicrowave.pause());
        assertEquals(MicrowaveOvenState.COOKING, testMicrowave.resume());
        assertEquals(MicrowaveOvenState.PAUSED, testMicrowave.pause());
        assertEquals(MicrowaveOvenState.COOKING, testMicrowave.resume());
        assertEquals(null, testMicrowave.setTime(10,0));
        assertEquals(null, testMicrowave.resume());
        assertEquals(null, testMicrowave.cancel());
        assertEquals(null, testMicrowave.start());
        assertEquals(null, testMicrowave.setPowerLevel(20));
    }

    @Test
    public void testSetTime5(){
        assertEquals(MicrowaveOvenState.IDLE, testMicrowave.getCurrentState());
        assertEquals(MicrowaveOvenState.PROGRAMMED, testMicrowave.setTime(10,0));
        assertEquals(MicrowaveOvenState.COOKING, testMicrowave.start());
        assertEquals(MicrowaveOvenState.PAUSED, testMicrowave.pause());
        assertEquals(MicrowaveOvenState.IDLE, testMicrowave.cancel());
        assertEquals(null, testMicrowave.pause());
        assertEquals(null, testMicrowave.resume());
        assertEquals(null, testMicrowave.cancel());
        assertEquals(null, testMicrowave.start());
        assertEquals(null, testMicrowave.setPowerLevel(10));

    }


    @Test
    public void testSetTime6(){
        assertEquals(MicrowaveOvenState.IDLE, testMicrowave.getCurrentState());
        assertEquals(MicrowaveOvenState.PROGRAMMED, testMicrowave.setTime(0,0));
        assertEquals(MicrowaveOvenState.IDLE, testMicrowave.cancel());
        assertEquals(null, testMicrowave.pause());
        assertEquals(null, testMicrowave.resume());
        assertEquals(null, testMicrowave.cancel());
        assertEquals(null, testMicrowave.start());
        assertEquals(null, testMicrowave.setPowerLevel(10));

    }

}