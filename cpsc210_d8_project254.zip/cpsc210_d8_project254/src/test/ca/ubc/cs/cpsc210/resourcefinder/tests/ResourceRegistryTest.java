package ca.ubc.cs.cpsc210.resourcefinder.tests;

import ca.ubc.cs.cpsc210.resourcefinder.model.Resource;
import ca.ubc.cs.cpsc210.resourcefinder.model.ResourceRegistry;
import ca.ubc.cs.cpsc210.resourcefinder.model.Service;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static ca.ubc.cs.cpsc210.resourcefinder.model.Service.FOOD;
import static ca.ubc.cs.cpsc210.resourcefinder.model.Service.SENIOR;
import static ca.ubc.cs.cpsc210.resourcefinder.model.Service.SHELTER;
import static org.junit.jupiter.api.Assertions.*;

// unit tests for ResourceRegistry class
public class ResourceRegistryTest {
    private ResourceRegistry testRegistry;
    private Resource r1;
    private Resource r2;
    private Resource r3;
    private Resource r4;

    @BeforeEach
    public void runBefore() {
        testRegistry = new ResourceRegistry();
        r1 = new Resource("Res 1", null);
        r2 = new Resource("Res 2", null);
        r3 = new Resource("Res 3", null);
        r4 = new Resource("Res 4", null);
    }

    @Test
    public void testResourceRegistry() {
        List<Resource> resources = testRegistry.getResources();
        assertEquals(0, resources.size());
    }

    @Test
    public void testAddResource() {
        testRegistry.addResource(r1);
        List<Resource> resources = testRegistry.getResources();
        assertEquals(1, resources.size());
        assertTrue(resources.contains(r1));
    }

    @Test
    public void testGetResourcesOfferingService0() {
        r1.addService(FOOD);
        r1.addService(Service.SHELTER);
        r2.addService(Service.YOUTH);
        r2.addService(FOOD);
        testRegistry.addResource(r1);
        testRegistry.addResource(r2);
        List<Resource> resources = testRegistry.getResources();
        testRegistry.getResourcesOfferingService(FOOD);
        assertEquals(2, resources.size());
        assertTrue(resources.contains(r1));
        assertTrue(resources.contains(r2));
    }

    @Test
    public void testGetResourcesOfferingService1() {
        r1.addService(FOOD);
        r1.addService(Service.SHELTER);
        testRegistry.addResource(r1);
        List<Resource> resources = testRegistry.getResources();
        testRegistry.getResourcesOfferingService(FOOD);
        testRegistry.getResourcesOfferingService(SHELTER);
        testRegistry.getResourcesOfferingService(SENIOR);
        assertEquals(1, resources.size());
        assertTrue(resources.contains(r1));
    }


    @Test
    public void testGetResourcesOfferingAllServicesInSet0() {
        r1.addService(FOOD);
        r1.addService(Service.SHELTER);
        r2.addService(Service.YOUTH);
        r2.addService(FOOD);
        testRegistry.addResource(r1);
        testRegistry.addResource(r2);
        Set<Service> s1 = new HashSet<>();
        s1.add(Service.FOOD);
        assertEquals(2, testRegistry.getResourcesOfferingAllServicesInSet(s1).size());
        assertTrue(testRegistry.getResourcesOfferingAllServicesInSet(s1).contains(r1));
        assertTrue(testRegistry.getResourcesOfferingAllServicesInSet(s1).contains(r2));
    }

    @Test
    public void testGetResourcesOfferingAllServicesInSet1() {
        r3.addService(Service.SENIOR);
        r4.addService(Service.SHELTER);
        r4.addService(FOOD);
        r4.addService(Service.LEGAL);
        testRegistry.addResource(r4);
        testRegistry.addResource(r3);
        Set<Service> s1 = new HashSet<>();
        s1.add(Service.FOOD);
        s1.add(Service.LEGAL);
        testRegistry.getResourcesOfferingAllServicesInSet(s1);
        assertEquals(1, testRegistry.getResourcesOfferingAllServicesInSet(s1).size());
        assertTrue(testRegistry.getResourcesOfferingAllServicesInSet(s1).contains(r4));
        assertFalse(testRegistry.getResourcesOfferingAllServicesInSet(s1).contains(r3));
    }

    @Test
    public void testGetResourcesOfferingAnyServicesInSet() {
        r3.addService(Service.SENIOR);
        r4.addService(Service.SHELTER);
        r4.addService(FOOD);
        r4.addService(Service.LEGAL);
        testRegistry.addResource(r4);
        testRegistry.addResource(r3);
        Set<Service> s1 = new HashSet<>();
        s1.add(Service.SENIOR);
        assertEquals(1, testRegistry.getResourcesOfferingAnyServicesInSet(s1).size());
        assertFalse(testRegistry.getResourcesOfferingAnyServicesInSet(s1).contains(r4));
        assertTrue(testRegistry.getResourcesOfferingAllServicesInSet(s1).contains(r3));
    }



    // MODIFIES: this
    // EFFECTS:  adds services to resources and resources to registry
    private void loadResources() {
        r1.addService(FOOD);
        r1.addService(Service.SHELTER);
        r2.addService(Service.YOUTH);
        r2.addService(FOOD);
        r3.addService(Service.SENIOR);
        r4.addService(Service.SHELTER);
        r4.addService(FOOD);
        r4.addService(Service.LEGAL);

        testRegistry.addResource(r1);
        testRegistry.addResource(r2);
        testRegistry.addResource(r3);
        testRegistry.addResource(r4);
    }
}