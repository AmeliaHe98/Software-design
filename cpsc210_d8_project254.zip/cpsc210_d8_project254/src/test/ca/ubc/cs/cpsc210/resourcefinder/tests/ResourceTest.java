package ca.ubc.cs.cpsc210.resourcefinder.tests;

import ca.ubc.cs.cpsc210.resourcefinder.model.Resource;
import ca.ubc.cs.cpsc210.resourcefinder.model.Service;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

// unit tests for Resource class
public class ResourceTest {
    private Resource testResource;
    private Set<Service> s1;

    @BeforeEach
    public void runBefore() {
        testResource = new Resource("Family Services", null);
        s1 = new HashSet<>();
        s1.add(Service.SHELTER);
        s1.add(Service.FOOD);
        s1.add(Service.COUNSELLING);
        s1.add(Service.YOUTH);
        s1.add(Service.LEGAL);
        s1.add(Service.SENIOR);
    }

    @Test
    public void testResource() {
        assertEquals("Family Services", testResource.getName());
        assertNull(testResource.getContactInfo());
    }


    @Test
    public void testOffersService0() {
        testResource.addService(Service.SHELTER);
        assertTrue( testResource.offersService(Service.SHELTER));
    }

    @Test
    public void testOffersService1() {
        testResource.addService(Service.SHELTER);
        assertFalse( testResource.offersService(Service.FOOD));
    }

    @Test
    public void test0ffersAllServicesInSet0() {
        assertFalse(testResource.offersAllServicesInSet(s1));
    }
    @Test
    public void test0ffersAllServicesInSet1() {
        testResource.addService(Service.SHELTER);
        testResource.addService(Service.FOOD);
        assertFalse( testResource.offersAllServicesInSet(s1));
    }

    @Test
    public void test0ffersAllServicesInSet2() {
        testResource.addService(Service.SHELTER);
        testResource.addService(Service.FOOD);
        testResource.addService(Service.COUNSELLING);
        testResource.addService(Service.YOUTH);
        testResource.addService(Service.LEGAL);
        testResource.addService(Service.SENIOR);
        assertTrue( testResource.offersAllServicesInSet(s1));
    }

    @Test
    public void test0ffersAnyServicesInSet0() {
        assertFalse( testResource.offersAnyServicesInSet(s1));
    }
    @Test
    public void test0ffersAnyServicesInSet1() {
        testResource.addService(Service.SHELTER);
        testResource.addService(Service.FOOD);
        assertTrue( testResource.offersAnyServicesInSet(s1));
    }

    @Test
    public void testAddSerivce() {
        testResource.addService(Service.SHELTER);
        assertTrue(testResource.offersService(Service.SHELTER));
    }

    @Test
    public void testRemoveSerivce() {
        testResource.addService(Service.SHELTER);
        testResource.removeService(Service.SHELTER);
        assertFalse(testResource.offersService(Service.SHELTER));
    }
}