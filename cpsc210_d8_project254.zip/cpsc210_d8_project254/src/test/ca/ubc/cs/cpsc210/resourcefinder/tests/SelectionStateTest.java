package ca.ubc.cs.cpsc210.resourcefinder.tests;

import ca.ubc.cs.cpsc210.resourcefinder.model.Resource;
import ca.ubc.cs.cpsc210.resourcefinder.model.ResourceRegistry;
import ca.ubc.cs.cpsc210.resourcefinder.model.SelectionState;
import ca.ubc.cs.cpsc210.resourcefinder.model.Service;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;


// unit tests for SelectionState class
public class SelectionStateTest {
    private SelectionState testSelectionState;
    private ResourceRegistry registry;
    private Resource r1;
    private Resource r2;
    private Resource r3;
    private Resource r4;

    @BeforeEach
    public void runBefore() {
        registry = new ResourceRegistry();
        loadResources();

        testSelectionState = new SelectionState(registry);
    }

    @Test
    public void testResourceRegistry0() {
        Set newSet = new HashSet();
        newSet.add(r1);
        newSet.add(r2);
        newSet.add(r3);
        newSet.add(r4);
        assertEquals(newSet, testSelectionState.getResourcesWithSelectedServices());
    }
    @Test
    public void testResourceRegistry1() {
        Set newSet = new HashSet();
        newSet.add(r1);
        newSet.add(r2);
        newSet.add(r4);
        assertTrue(testSelectionState.getResourcesWithSelectedServices().containsAll(newSet));
    }

    @Test
    public void testAddService() {
        testSelectionState.selectService(Service.FOOD);
        assertEquals(3, testSelectionState.getResourcesWithSelectedServices().size());
    }

    @Test
    public void testDeselectService() {
        testSelectionState.deselectService(Service.FOOD);
        assertEquals(4, testSelectionState.getResourcesWithSelectedServices().size());
    }


    @Test
    public void testSetSelectAny() {
        testSelectionState.setSelectAny();
        assertTrue(testSelectionState.isAnySelected());
    }

    @Test
    public void testSetSelectAll() {
        testSelectionState.setSelectAll();
        assertFalse(testSelectionState.isAnySelected());
    }

    // MODIFIES: this
    // EFFECTS:  adds services to resources and resources to resource registry
    private void loadResources() {
        r1 = new Resource("Res 1", null);
        r2 = new Resource("Res 2", null);
        r3 = new Resource("Res 3", null);
        r4 = new Resource("Res 4", null);

        r1.addService(Service.FOOD);
        r1.addService(Service.SHELTER);
        r2.addService(Service.YOUTH);
        r2.addService(Service.FOOD);
        r3.addService(Service.SENIOR);
        r3.addService(Service.COUNSELLING);
        r4.addService(Service.SHELTER);
        r4.addService(Service.FOOD);
        r4.addService(Service.LEGAL);

        registry.addResource(r1);
        registry.addResource(r2);
        registry.addResource(r3);
        registry.addResource(r4);
    }
}