package ca.ubc.cpsc210.quizbuilder.model.question;

public class MultiplicationQuestion extends Question {
    private int factor1;
    private int factor2;
    private int product;

    // REQUIRES: maxMark must be >= 0
    // EFFECTS: constructs short answer question with given maximum mark, question statement
    // and correct answer
    public MultiplicationQuestion(double maxMark, int factor1, int factor2) {
        super(maxMark, factor1 + "*" + factor2);
        this.factor1 = factor1;
        this.factor2 = factor2;
        Caculator();
    }

    public int Caculator() {
        product = factor1 * factor2;
        return product;
    }


    @Override
    public boolean isCorrect(String answer) {
        try {
            int answerI = Integer.parseInt(answer);
            if(Caculator()==answerI)
                return true;
            else
                return false;
        } catch (NumberFormatException e) {
            System.out.println("not an integer");
            return false;
        }
    }
}

