package ca.ubc.cpsc210.quizbuilder.test;

import ca.ubc.cpsc210.quizbuilder.model.question.MultiplicationQuestion;
import ca.ubc.cpsc210.quizbuilder.model.question.Question;
import ca.ubc.cpsc210.quizbuilder.model.question.TrueFalseQuestion;
import ca.ubc.cpsc210.quizbuilder.model.questionslist.QuestionsList;
import ca.ubc.cpsc210.quizbuilder.model.quiz.Quiz;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class MultiplicationQuestionTest extends QuizBuilderTests {
    private Question q1, q2;

    @BeforeEach
    public void runBefore() {
        q1 = new MultiplicationQuestion(8, 1, 6);
        q2 = new MultiplicationQuestion(16, 2, 4);


    }

    @Test
    public void testMultiplicationQuestion() {
        assertTrue(q1.isCorrect("6"));
        assertFalse(q1.isCorrect("7"));

    }
}