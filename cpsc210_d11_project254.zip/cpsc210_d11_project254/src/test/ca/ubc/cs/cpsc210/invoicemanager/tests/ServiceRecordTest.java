package ca.ubc.cs.cpsc210.invoicemanager.tests;

import ca.ubc.cs.cpsc210.invoicemanager.model.*;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;


// Unit tests for ServiceRecord
public class ServiceRecordTest {
    private AbstractServiceRecord testAbstractServiceRecord;

    @Test
    public void testRegular() {
        testAbstractServiceRecord = new RegularServiceRecord (ServiceType.REGULAR, 2);

        assertEquals(RegularServiceRecord.REG_SERVICEPTS_BASE + 2 * RegularServiceRecord.REG_SERVICEPTS_HOURLY,
                testAbstractServiceRecord.getServicePoints());

        int calloutFee = AbstractServiceRecord.REG_CALLOUT;
        int serviceFee = RegularServiceRecord.REG_SERVICE_HOURLY * 2;
        assertEquals(calloutFee, testAbstractServiceRecord.getCalloutFee());
        assertEquals(serviceFee, testAbstractServiceRecord.getServiceFee());

        Invoice invoice = testAbstractServiceRecord.getInvoice();
        assertEquals(calloutFee + serviceFee, invoice.getAmountOwing());
    }

    @Test
    public void testAfterHours() {
        testAbstractServiceRecord = new AfterHoursServiceRecord(ServiceType.AFTER_HOURS, 2);

        assertEquals(RegularServiceRecord.AFTER_HOURS_SERVICEPTS_BASE + 2 * RegularServiceRecord.AFTER_HOURS_SERVICEPTS_HOURLY,
                testAbstractServiceRecord.getServicePoints());

        int calloutFee = RegularServiceRecord.AFTER_HOURS_CALLOUT;
        int serviceFee = RegularServiceRecord.AFTER_HOURS_SERVICE_HOURLY * 2;
        assertEquals(calloutFee, testAbstractServiceRecord.getCalloutFee());
        assertEquals(serviceFee, testAbstractServiceRecord.getServiceFee());

        Invoice invoice = testAbstractServiceRecord.getInvoice();
        assertEquals(calloutFee + serviceFee, invoice.getAmountOwing());
    }

    @Test
    public void testEmergency() {
        testAbstractServiceRecord = new EmergencyServiceRecord (ServiceType.EMERGENCY, 2);

        assertEquals(RegularServiceRecord.EMERG_SERVICEPTS_BASE + 2 * RegularServiceRecord.EMERG_SERVICEPTS_HOURLY,
                testAbstractServiceRecord.getServicePoints());

        int calloutFee = RegularServiceRecord.EMERG_CALLOUT;
        int serviceFee = RegularServiceRecord.EMERG_SERVICE_HOURLY * 2;
        assertEquals(calloutFee, testAbstractServiceRecord.getCalloutFee());
        assertEquals(serviceFee, testAbstractServiceRecord.getServiceFee());

        Invoice invoice = testAbstractServiceRecord.getInvoice();
        assertEquals(calloutFee + serviceFee, invoice.getAmountOwing());
    }
}