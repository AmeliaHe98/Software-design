package ca.ubc.cs.cpsc210.invoicemanager.model;

public class RegularServiceRecord extends AbstractServiceRecord{
    public static int REG_CALLOUT = 80;
    protected ServiceType serviceType;
    protected int hours;
    protected int recordID;
    private Invoice invoice;
    public static int REG_SERVICE_HOURLY = 80;
    public static int REG_SERVICEPTS_BASE = 10;
    public static int REG_SERVICEPTS_HOURLY = 2;
    public static int AFTER_HOURS_CALLOUT = 120;
    public static int AFTER_HOURS_SERVICE_HOURLY = 100;
    public static int AFTER_HOURS_SERVICEPTS_BASE = 5;
    public static int AFTER_HOURS_SERVICEPTS_HOURLY = 1;
    public static int EMERG_CALLOUT = 150;
    public static int EMERG_SERVICE_HOURLY = 100;
    public static int EMERG_SERVICEPTS_BASE = 0;
    public static int EMERG_SERVICEPTS_HOURLY = 0;
    private static int nextRecordID = 0;

    public RegularServiceRecord(ServiceType serviceType, int hours) {
        super(serviceType, hours);
        this.hours = hours;
        this.recordID = ++nextRecordID;
        this.serviceType = serviceType;
        buildInvoice();
    }

    @Override
    // EFFECTS: returns number of service points earned with this service record
    public int getServicePoints() {
        int servicePoints = 0;
        servicePoints = REG_SERVICEPTS_BASE + hours * REG_SERVICEPTS_HOURLY;
        return servicePoints;
    }

    @Override
    // EFFECTS: returns callout fee in $ for this service record
    public int getCalloutFee() {
        int calloutFee = 0;
        calloutFee = REG_CALLOUT;
        return calloutFee;
    }

    @Override
    // EFFECTS: returns service fee in $ for this service record
    public int getServiceFee() {
        int serviceFee = 0;
        serviceFee = REG_SERVICE_HOURLY * hours;
        return serviceFee;
    }

}
