package ca.ubc.cs.cpsc210.invoicemanager.model;

public class EmergencyServiceRecord extends  AbstractServiceRecord{
    public static int REG_CALLOUT = 80;
    protected ServiceType serviceType;
    protected int hours;
    protected int recordID;
    private Invoice invoice;
    public static int EMERG_CALLOUT = 150;
    public static int EMERG_SERVICE_HOURLY = 100;
    public static int EMERG_SERVICEPTS_BASE = 0;
    public static int EMERG_SERVICEPTS_HOURLY = 0;
    private static int nextRecordID = 0;

    public EmergencyServiceRecord(ServiceType serviceType, int hours) {
        super(serviceType, hours);
        this.hours = hours;
        this.recordID = ++nextRecordID;
        this.serviceType = serviceType;
        buildInvoice();
    }

    @Override
    // EFFECTS: returns number of service points earned with this service record
    public int getServicePoints() {
        int servicePoints = 0;
        servicePoints = EMERG_SERVICEPTS_BASE + hours * EMERG_SERVICEPTS_HOURLY;
        return servicePoints;
    }

    @Override
    // EFFECTS: returns callout fee in $ for this service record
    public int getCalloutFee() {
        int calloutFee = 0;
        calloutFee = EMERG_CALLOUT;
        return calloutFee;
    }

    @Override
    // EFFECTS: returns service fee in $ for this service record
    public int getServiceFee() {
        int serviceFee = 0;
        serviceFee = EMERG_SERVICE_HOURLY * hours;
        return serviceFee;
    }
}
