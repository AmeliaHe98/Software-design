package ca.ubc.cs.cpsc210.invoicemanager.model;

public class DiscountServiceRecord extends AbstractServiceRecord {
    protected ServiceType serviceType;
    protected int hours;
    protected int recordID;
    public static int DIS_SERVICE_HOURLY = 80;
    protected static int nextRecordID = 0;

    public DiscountServiceRecord(ServiceType serviceType, int hours) {
        super(serviceType, hours);
        this.hours = hours;
        this.recordID = ++nextRecordID;
        this.serviceType = serviceType;
        buildInvoice();
    }

    @Override
    // EFFECTS: returns number of service points earned with this service record
    public int getServicePoints() {
        return 0;
    }

    @Override
    // EFFECTS: returns callout fee in $ for this service record
    public int getCalloutFee() {
        return 0;
    }

    @Override
    // EFFECTS: returns service fee in $ for this service record
    public int getServiceFee() {
        int serviceFee = 0;
        serviceFee = DIS_SERVICE_HOURLY * hours;
        return serviceFee;
    }
}

