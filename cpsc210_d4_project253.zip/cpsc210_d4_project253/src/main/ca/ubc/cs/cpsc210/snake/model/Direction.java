package ca.ubc.cs.cpsc210.snake.model;

// Represents a direction of travel for the snake.
public enum Direction {
    UP, DOWN, LEFT, RIGHT
}
