package ca.ubc.cs.cpsc210.snake.tests;

import ca.ubc.cs.cpsc210.snake.model.Cell;
import ca.ubc.cs.cpsc210.snake.model.Food;
import ca.ubc.cs.cpsc210.snake.model.SnakeGame;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static ca.ubc.cs.cpsc210.snake.model.Food.DECAY_AMOUNT;
import static ca.ubc.cs.cpsc210.snake.model.Food.INITIAL_NUTRITIONAL_VALUE;
import static org.junit.jupiter.api.Assertions.*;

// jUnit tests for Food class
public class FoodTest {
    private Food testFood;

    @BeforeEach
    public void runBefore() {
        testFood = new Food(new Cell(SnakeGame.BOARD_ROWS / 2, SnakeGame.BOARD_COLS / 2));
    }

    @Test
    public void testConstructor (){
        assertEquals(new Cell(SnakeGame.BOARD_ROWS / 2, SnakeGame.BOARD_COLS / 2), testFood.getPosition());
        assertEquals(INITIAL_NUTRITIONAL_VALUE, testFood.getNutritionalValue());

    }

    @Test
    public void testGetPosition (){
        assertEquals(new Cell(SnakeGame.BOARD_ROWS / 2, SnakeGame.BOARD_COLS / 2), testFood.getPosition());
    }

    @Test
    public void testDecay0 (){
        testFood.decay();
        assertEquals(INITIAL_NUTRITIONAL_VALUE-DECAY_AMOUNT, testFood.getNutritionalValue());
    }

    @Test
    public void testDecay1 (){
        testFood.decay();
        testFood.decay();
        testFood.decay();
        testFood.decay();
        testFood.decay();
        testFood.decay();
        testFood.decay();
        testFood.decay();
        testFood.decay();
        testFood.decay();
        testFood.decay();
        assertEquals(0, testFood.getNutritionalValue());
    }

    @Test
    public void testGetNutritionalValue (){
        assertEquals(INITIAL_NUTRITIONAL_VALUE, testFood.getNutritionalValue());
    }
}