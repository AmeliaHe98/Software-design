package ca.ubc.cs.cpsc210.productrating.tests;

import ca.ubc.cs.cpsc210.productrating.model.Rating;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

// unit tests for the Rating class
public class RatingTest {

    Rating testR;
    //TODO: design unit tests for Rating class

    @BeforeEach
    void rating(){
        testR = new Rating();
    }

    @Test
    public void testConstructor(){
        assertEquals(0, testR.getNumVotes());
    }

    @Test
    public void testResetVotes(){
        testR.addVote(3);
        testR.addVote(1);
        testR.resetVotes();
        assertEquals(0, testR.getNumVotes());
    }

    @Test
    public void testAddVote(){
        testR.addVote(0);
        assertEquals(0, testR.computeScore());
        testR.addVote(3);
        assertEquals(1.5, testR.computeScore());
        testR.addVote(3);
        assertEquals(2, testR.computeScore());
    }

    @Test
    public void testGetNumVotes(){
        testR.addVote(0);
        testR.addVote(1);
        testR.addVote(2);
        assertEquals(3, testR.getNumVotes());
    }


    @Test
    public void testComputeScore1(){
        testR.addVote(0);
        assertEquals(0, testR.computeScore());
    }

    @Test
    public void testComputeScore2(){
        testR.addVote(3);
        assertEquals(3.0, testR.computeScore());
    }

    @Test
    public void testComputeScore3(){
        testR.addVote(3);
        testR.addVote(2);
        testR.addVote(1);
        testR.addVote(0);
        assertEquals(1.5, testR.computeScore());
    }


    @Test
    public void testString(){
        testR.addVote(0);
        assertEquals("", testR.toString());
        testR.addVote(2);
        assertEquals("*", testR.toString());
        testR.addVote(3);
        assertEquals("*", testR.toString());
        testR.addVote(3);
        assertEquals("**", testR.toString());
    }

    @Test
    public void testString2(){
        testR.addVote(3);
        assertEquals("***", testR.toString());
    }



}