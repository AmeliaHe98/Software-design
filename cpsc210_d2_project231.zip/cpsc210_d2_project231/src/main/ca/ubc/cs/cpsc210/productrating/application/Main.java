package ca.ubc.cs.cpsc210.productrating.application;

// Simple application to illustrate use of Rating class
public class Main {
    public static void main(String[] args) {
        //TODO: write your application code here
        System.out.println(4 + 5);
        System.out.println("This is not a very interesting message.");


    }
}
