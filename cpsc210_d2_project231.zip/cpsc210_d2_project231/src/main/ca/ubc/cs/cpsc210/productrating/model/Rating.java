package ca.ubc.cs.cpsc210.productrating.model;

// Represents a rating (for a product or movie or ...)
// that is based on an arbitrary number of votes on a scale
// of 0 to MAX_VOTE stars
public class Rating {
    public static final int MAX_VOTE = 3;
    private int sumOfVotes;
    private int numOfVotes;

    //REQUIRES: NA
    //MODIFIES: this
    //EFFECTS: initializes each newly created Rating object so that no votes have been cast.
    public Rating (){
        sumOfVotes = 0;
        numOfVotes = 0;
    }
    //REQUIRES: NA
    //MODIFIES: this
    //EFFECTS: resets votes to 0 so no votes have been cast
    public void resetVotes(){
        sumOfVotes = 0;
        numOfVotes = 0;
    }

    //REQUIRES: 0 =< num => 3
    //MODIFIES: votes
    //EFFECTS: adds num to sumOfVotes
    public void addVote (int sum){
            sumOfVotes += sum;
            numOfVotes++;

    }
    //REQUIRES: NA
    //MODIFIES: this
    //EFFECTS: returns number of votes
    public int getNumVotes(){
        return numOfVotes;
    }

    //REQUIRES: at least one vote has to be casted
    //MODIFIES: this
    //EFFECTS: average of all votes
    public double computeScore(){
            return (double)sumOfVotes/(double)numOfVotes;
    }

    //REQUIRES: 0>= avgVotes <= 3
    //MODIFIES: this
    //EFFECTS: produce "*" in accordance to rounded avgVotes
    public String toString(){
        String inst = "";
        for (int i = 0; i < Math.floor(computeScore()); i++) {
            inst += "*";
        }
        return inst;
    }
}
